package com.ganta.googlemaps;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Toast;

public class Main extends MapActivity implements LocationListener {
    
    MapView map;
    long start; // press
    long stop; // release
    MyLocationOverlay compass;
    MapController controller;
    int x, y;
    GeoPoint touchedPoint;
    Drawable d;
    List<Overlay> overlayList;
    LocationManager lm;
    String provider;
    int lat, lon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        map = (MapView) findViewById(R.id.mvMain);
        map.setBuiltInZoomControls(true);
        Touchy t = new Touchy();
        overlayList = map.getOverlays();
        overlayList.add(t);
        compass = new MyLocationOverlay(Main.this, map);
        overlayList.add(compass);
        controller = map.getController();
        GeoPoint point = new GeoPoint(51643234, 7848593);
        controller.animateTo(point);
        controller.setZoom(10);
        d = getResources().getDrawable(R.drawable.ic_launcher);
        
        //placing pintpoint at a location:
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria cri = new Criteria();
        provider = lm.getBestProvider(cri, false);
        Location location = lm.getLastKnownLocation(provider);
        if(location != null) {
            lat = (int) location.getLatitude();
            lon = (int) location.getLongitude();
            GeoPoint ourLocation = new GeoPoint(lat, lon);
            OverlayItem item = new OverlayItem(ourLocation, "Whats up", "This is snippet");
            CustomPinPoint custom = new CustomPinPoint(d, Main.this);
            custom.insertPinPoint(item);
            overlayList.add(custom);
        }
        else {
            Toast t1 = Toast.makeText(Main.this, "Couldn't get Provider", Toast.LENGTH_SHORT);
            t1.show();
        }
        
    }

    
    @Override
    protected void onPause() {
        compass.disableCompass();
        super.onPause();
        lm.removeUpdates(this);
    }

    @Override
    protected void onResume() {
        compass.enableCompass();
        super.onResume();
        lm.requestLocationUpdates(provider, 500, 1, this);
    }

    @Override
    protected boolean isRouteDisplayed() {
        // TODO Auto-generated method stub
        return false;
    }
    
    class Touchy extends Overlay {

        @Override
        public boolean onTouchEvent(MotionEvent e, MapView mapView) {
            if(e.getAction() == MotionEvent.ACTION_DOWN) {
                start = e.getEventTime();
                x = (int) e.getX();
                y = (int) e.getY();
                touchedPoint = map.getProjection().fromPixels(x, y);
                
            }
            else if(e.getAction() == MotionEvent.ACTION_UP) {
                stop = e.getEventTime();
            }
            if(stop - start > 1500) {
                AlertDialog alert = new AlertDialog.Builder(Main.this).create();
                alert.setTitle("Pick an option.");
                alert.setMessage("Select an option, and do it quick.");
                alert.setButton("place a pin", new DialogInterface.OnClickListener() {
                    
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        
                        OverlayItem item = new OverlayItem(touchedPoint, "Whats up", "This is snippet");
                        CustomPinPoint custom = new CustomPinPoint(d, Main.this);
                        custom.insertPinPoint(item);
                        overlayList.add(custom);
                        
                    }
                });
                alert.setButton2("get the address", new DialogInterface.OnClickListener() {
                    
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Geocoder geocoder = new Geocoder(getBaseContext(), Locale.getDefault());
                        try {
                            List<Address> address = geocoder.getFromLocation(touchedPoint.getLatitudeE6()/1E6, touchedPoint.getLongitudeE6()/1E6, 1);
                            if(address.size() > 0) {
                                String display = "";
                                for( int i=0; i< address.get(0).getMaxAddressLineIndex(); i++) {
                                    display += address.get(0).getAddressLine(i) + "\n";
                                }
                                Toast t = Toast.makeText(getBaseContext(), display, Toast.LENGTH_LONG);
                                t.show();
                            }
                        } catch (IOException e ) {
                            e.printStackTrace();
                        } finally {
                            
                        }
                    }
                });
                alert.setButton3("Toggle View", new DialogInterface.OnClickListener() {
                    
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(map.isStreetView()) {
                            map.setSatellite(true);
                            map.setStreetView(false);
                        }
                        else {
                            map.setSatellite(false);
                            map.setStreetView(true);
                        }
                    }
                });
                alert.show();
            }
            return true;
        }
        
    }

    @Override
    public void onLocationChanged(Location l) {
        // TODO Auto-generated method stub
        lat = (int) (l.getLatitude() * 1E6);
        lon = (int) (l.getLongitude() * 1E6);
        GeoPoint ourLocation = new GeoPoint(lat, lon);
        OverlayItem item = new OverlayItem(ourLocation, "Whats up", "This is snippet");
        CustomPinPoint custom = new CustomPinPoint(d, Main.this);
        custom.insertPinPoint(item);
        overlayList.add(custom);
    }


    @Override
    public void onProviderDisabled(String arg0) {
        // TODO Auto-generated method stub
        
    }


    @Override
    public void onProviderEnabled(String arg0) {
        // TODO Auto-generated method stub
        
    }


    @Override
    public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
        // TODO Auto-generated method stub
        
    }

}
